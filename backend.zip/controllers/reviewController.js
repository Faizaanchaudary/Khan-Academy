import Review from '../models/Review.js';
import User from '../models/User.js';

export const addReview = async (req, res) => {
  try {
    const { rating, title, comment } = req.body;
    const studentId = req.user._id;

    // Check if user is a student
    if (req.user.role !== 'student') {
      return res.status(403).json({
        success: false,
        message: 'Only students can submit reviews'
      });
    }

    const review = await Review.create({
      studentId,
      rating,
      title: title.trim(),
      comment: comment ? comment.trim() : undefined,
      status: 'pending'
    });

    // Populate student details
    await review.populate('studentId', 'firstName lastName profilePic');

    res.status(201).json({
      success: true,
      message: 'Review submitted successfully',
      data: {
        review
      }
    });
  } catch (error) {
    console.error('Add review error:', error);
    
    if (error.name === 'ValidationError') {
      const errors = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors
      });
    }

    res.status(500).json({
      success: false,
      message: 'Internal server error while submitting review'
    });
  }
};

export const getReviews = async (req, res) => {
  try {
    const { status = 'pending', page = 1, limit = 10 } = req.query;

    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can view reviews'
      });
    }

    // Get all reviews with the specified status
    const query = { status };
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const reviews = await Review.find(query)
      .populate('studentId', 'firstName lastName profilePic')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Review.countDocuments(query);

    res.json({
      success: true,
      message: 'Reviews retrieved successfully',
      data: {
        reviews,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / parseInt(limit)),
          totalReviews: total,
          hasNextPage: skip + reviews.length < total,
          hasPrevPage: parseInt(page) > 1
        }
      }
    });
  } catch (error) {
    console.error('Get reviews error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while retrieving reviews'
    });
  }
};

export const approveReview = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can approve reviews'
      });
    }

    const review = await Review.findById(id);
    if (!review) {
      return res.status(404).json({
        success: false,
        message: 'Review not found'
      });
    }

    if (review.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: 'Review has already been processed'
      });
    }

    review.status = 'approved';
    review.approvedAt = new Date();
    await review.save();

    // Populate student details
    await review.populate('studentId', 'firstName lastName profilePic');

    res.json({
      success: true,
      message: 'Review approved successfully',
      data: {
        review
      }
    });
  } catch (error) {
    console.error('Approve review error:', error);
    
    if (error.name === 'CastError') {
      return res.status(400).json({
        success: false,
        message: 'Invalid review ID format'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Internal server error while approving review'
    });
  }
};

export const declineReview = async (req, res) => {
  try {
    const { id } = req.params;

    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can decline reviews'
      });
    }

    const review = await Review.findById(id);
    if (!review) {
      return res.status(404).json({
        success: false,
        message: 'Review not found'
      });
    }

    if (review.status !== 'pending') {
      return res.status(400).json({
        success: false,
        message: 'Review has already been processed'
      });
    }

    review.status = 'declined';
    review.declinedAt = new Date();
    await review.save();

    // Populate student details
    await review.populate('studentId', 'firstName lastName profilePic');

    res.json({
      success: true,
      message: 'Review declined successfully',
      data: {
        review
      }
    });
  } catch (error) {
    console.error('Decline review error:', error);
    
    if (error.name === 'CastError') {
      return res.status(400).json({
        success: false,
        message: 'Invalid review ID format'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Internal server error while declining review'
    });
  }
};

export const getStudentReviews = async (req, res) => {
  try {
    const studentId = req.user._id;
    const { page = 1, limit = 10 } = req.query;

    // Check if user is a student
    if (req.user.role !== 'student') {
      return res.status(403).json({
        success: false,
        message: 'Only students can view their own reviews'
      });
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const reviews = await Review.find({ studentId })
      .populate('studentId', 'firstName lastName profilePic')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Review.countDocuments({ studentId });

    res.json({
      success: true,
      message: 'Student reviews retrieved successfully',
      data: {
        reviews,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / parseInt(limit)),
          totalReviews: total,
          hasNextPage: skip + reviews.length < total,
          hasPrevPage: parseInt(page) > 1
        }
      }
    });
  } catch (error) {
    console.error('Get student reviews error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while retrieving student reviews'
    });
  }
};


export const getReviewsByStatus = async (req, res) => {
  try {
    const { status } = req.params;
    const { page = 1, limit = 10 } = req.query;

    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can view reviews'
      });
    }

    // Validate status parameter
    const validStatuses = ['pending', 'approved', 'declined'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be one of: pending, approved, declined'
      });
    }

    // Get all reviews with the specified status
    const query = { status };
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const reviews = await Review.find(query)
      .populate('studentId', 'firstName lastName profilePic')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Review.countDocuments(query);

    res.json({
      success: true,
      message: `${status.charAt(0).toUpperCase() + status.slice(1)} reviews retrieved successfully`,
      data: {
        reviews,
        status,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / parseInt(limit)),
          totalReviews: total,
          hasNextPage: skip + reviews.length < total,
          hasPrevPage: parseInt(page) > 1
        }
      }
    });
  } catch (error) {
    console.error('Get reviews by status error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while retrieving reviews by status'
    });
  }
};

export const getReviewCounts = async (req, res) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can view review counts'
      });
    }

    // Get counts for each status
    const [pendingCount, approvedCount, declinedCount] = await Promise.all([
      Review.countDocuments({ status: 'pending' }),
      Review.countDocuments({ status: 'approved' }),
      Review.countDocuments({ status: 'declined' })
    ]);

    const totalCount = pendingCount + approvedCount + declinedCount;

    res.json({
      success: true,
      message: 'Review counts retrieved successfully',
      data: {
        counts: {
          pending: pendingCount,
          approved: approvedCount,
          declined: declinedCount,
          total: totalCount
        }
      }
    });
  } catch (error) {
    console.error('Get review counts error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while retrieving review counts'
    });
  }
};

export const getAllReviewsWithCounts = async (req, res) => {
  try {
    const { status = 'pending', page = 1, limit = 10 } = req.query;

    // Check if user is admin
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Only admins can view reviews'
      });
    }

    // Validate status parameter
    const validStatuses = ['pending', 'approved', 'declined'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Must be one of: pending, approved, declined'
      });
    }

    // Get counts for all statuses
    const [pendingCount, approvedCount, declinedCount] = await Promise.all([
      Review.countDocuments({ status: 'pending' }),
      Review.countDocuments({ status: 'approved' }),
      Review.countDocuments({ status: 'declined' })
    ]);

    const totalCount = pendingCount + approvedCount + declinedCount;

    // Get reviews for the requested status
    const query = { status };
    const skip = (parseInt(page) - 1) * parseInt(limit);

    const reviews = await Review.find(query)
      .populate('studentId', 'firstName lastName profilePic')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Review.countDocuments(query);

    res.json({
      success: true,
      message: 'Reviews and counts retrieved successfully',
      data: {
        reviews,
        currentStatus: status,
        counts: {
          pending: pendingCount,
          approved: approvedCount,
          declined: declinedCount,
          total: totalCount
        },
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(total / parseInt(limit)),
          totalReviews: total,
          hasNextPage: skip + reviews.length < total,
          hasPrevPage: parseInt(page) > 1
        }
      }
    });
  } catch (error) {
    console.error('Get all reviews with counts error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while retrieving reviews with counts'
    });
  }
};
